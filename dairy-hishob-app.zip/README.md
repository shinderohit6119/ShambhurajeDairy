# डेअरी हिशोब — Developer Handoff

This is a complete, self-contained mobile web app (PWA) for a dairy/milk-collection
center: farmer records, daily milk collection, advances (उचल), advance-cut monthly
billing, payment tracking, WhatsApp/SMS message generation, and reports.

## What's in this folder

```
index.html         ← the entire app (React + Tailwind, loaded from CDN — no build step)
manifest.json       ← PWA manifest (name, icons, colors, standalone display mode)
service-worker.js   ← enables offline caching once the app has been opened once
icon-192.png        ← app icon (192×192)
icon-512.png        ← app icon (512×512)
```

No `npm install` or build step is required — it's plain HTML/JS using CDN-hosted
React, ReactDOM and Babel, plus Tailwind's CDN build. You can open `index.html`
directly, but to get PWA installability and the service worker working you need
to serve it over **https** (see below).

## Data storage

All data (farmers, milk entries, advances, bills) is stored in the browser's
`localStorage`, per device. There is **no backend and no sync between devices** —
if the owner uses the app on two phones, the data will not match. If multi-device
sync is needed later, that requires adding a real backend (e.g. Firebase,
Supabase, or a small custom API) — happy to scope that separately if needed.

## 1. Host it somewhere (required for install + offline to work)

Any static host works. Two free, no-login-hassle options:

**Netlify Drop** (easiest):
1. Go to https://app.netlify.com/drop
2. Drag this whole folder onto the page
3. You get a live https URL instantly (e.g. `random-name.netlify.app`)

**GitHub Pages**:
1. Create a new GitHub repo, upload these files
2. Repo Settings → Pages → deploy from `main` branch, root folder
3. You get a URL like `username.github.io/repo-name`

Once hosted, opening the URL on an Android phone in Chrome will show the
"Add to Home Screen" / install prompt — that installs it as a standalone app
icon with no browser bar, and it will keep working offline after first load.

## 2. Turn it into a real installable APK

Once the app is hosted at a stable https URL (step 1), use **PWABuilder**
(free, made by Microsoft):

1. Go to https://www.pwabuilder.com
2. Paste your hosted URL and click "Start"
3. It will read `manifest.json` automatically and score the app
4. Click "Package for stores" → choose **Android**
5. Download the generated `.apk` / `.aab` file

This APK can be installed directly on Android phones (sideload), or submitted
to the Google Play Store if the owner wants store distribution — that requires
a one-time $25 Google Play developer account.

## 3. If you'd rather use Capacitor instead of PWABuilder

For a more native wrapper (access to native APIs later, nicer store presence):

```bash
npm install -g @capacitor/cli
npx cap init "डेअरी हिशोब" com.example.dairyhishob
npx cap add android
# copy index.html, manifest.json, icons into the www/ folder Capacitor creates
npx cap sync
npx cap open android   # opens Android Studio to build/sign the APK
```

## Notes for further development

- All UI strings are in Marathi; component structure is plain, readable React
  (no external state library, no router — just `useState` screen switching).
- Rate per liter is stored per-farmer (`ratePerLiter`) with a global default
  in Settings.
- "Advance Cut" is the monthly billing step: it sums that farmer's milk
  entries for the chosen month, lets the owner enter a deduction, and creates
  a `bills` record while reducing the farmer's advance balance.
- WhatsApp/SMS buttons use `wa.me` and `sms:` links — no API keys or backend
  needed, but they only work when tapped on a phone with WhatsApp/SMS installed.
